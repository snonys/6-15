
# Project Name
What the project do...
## Requirement
### Library
 - OPENCV VERSION 4.5.2
 - FOCATEK_STD_3.3.0_210221
 - QT 6.1.1
 - Neuro-R 2.2.1
 
### Model
Filename: xxxxx<br>
Training by Neuro-T 2.2.1<br>

### Hardware
- FOCATEK CAMERA MODEL NAME \* 1
- FOCATEK CAMERA MODEL NAME \* 2
- LIGHTING CONTROLLER \*2 

## Build
1. Install Visual Studio 2019 or above.
2. Set system enviorment.
3. Open sln file.
4. Build

System Enviorment

|Variable Name|Path|
| ------------ | ------------ |
|  OPENCV_DIR |  ex. C:\RJ45\opencv_4.5.2\build |
| NEURO-R_DIR  |  ex. C:\RJ45\NEURO-R|
| Model_DIR  |  ex. C:\RJ45\NEURO-R|

## Run
1. Set camera ip
2. execute RJ45.

Camera IP

|Camera|IP|
| ------------ | ------------ |
| Camera 1 | 192.168.1.33 |
| Camera 2 | 192.168.2.33|
| Camera 3 | 192.168.3.33|
